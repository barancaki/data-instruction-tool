BEGIN TRANSACTION;
CREATE TABLE "katilimcilar" (
"Firma" TEXT,
  "Adres" TEXT,
  "Telefon" TEXT,
  "E-posta" TEXT,
  "Web adresi" TEXT
);
INSERT INTO "katilimcilar" VALUES('ABB Elektrik A.Ş.','Aydınevler Mh. Siteler Yolu No: 1A/7 PK.34854 Maltepe / İSTANBUL - ASIA','+90 216 528 22 00','contact.center@tr.abb.com','http://www.abb.com.tr/');
INSERT INTO "katilimcilar" VALUES('ARİNVEL Enerji ve Kontrol Sistemleri San. Tic. Ltd. Şti.','Oruçreis Mh. Giyimkent Sitesi 20.Sk. No:85/A PK.34235 Esenler / İSTANBUL','+90 212 220 03 07','info@arinvel.com','http://www.arinvel.com/');
INSERT INTO "katilimcilar" VALUES('ASP Otomasyon A.Ş.','Barbaros Mah. Başkan Sk. No: 14/2 Üsküdar / İSTANBUL','+90 216 342 32 06','info@aspotomasyon.com','https://www.aspotomasyon.com/');
INSERT INTO "katilimcilar" VALUES('BEİJER Elektronik Tic. ve A.Ş.','Aydınevler Mh. Aslanbey Cd. No:5-7 Mert Plaza B Blok Kat:2 Ofis:5-6-7 D:8 PK.34854 Maltepe / İSTANBUL','+90 216 366 32 02','info.tr@beijerelectronics.com','https://www.beijerelektronik.com.tr/');
INSERT INTO "katilimcilar" VALUES('BİLGİ Otomasyon San. Tic. A.Ş.','Yukarı Dudullu Mh. 18 Mart Cd. Kartalbaba Sk. No:8 A/1 34775 Dudullu Osb Ümraniye/İSTANBUL','+90 216 540 88 78-84','info@bilgiotomasyon.com','https://www.bilgiotomasyon.com/');
INSERT INTO "katilimcilar" VALUES('BİLKO Bilgisayar Otomasyon ve Kontrol A.Ş.','Perpa Ticaret Merkezi B-Blok Kat:13 No:2536 TR-34385 Okmeydanı / İSTANBUL','+90 212 320 13 83','bilko@bilko.com.tr','https://www.bilko.tr/tr/');
INSERT INTO "katilimcilar" VALUES('DACEL Elektrik-Elektronik Mühendislik Sistemleri San. Tic. Ltd. Şti.','Oruçreis Mah. Tekstilkent Cd. Tekstilkent Sanayi Sit. A-08 Apt. No:10 AM/Z08-9 Esenler / İSTANBUL','+90 212 210 76 46','info@dacel.com.tr','https://www.dacelsolutions.com/');
INSERT INTO "katilimcilar" VALUES('DELTA GREENTECH Elektronik San. Ltd. Şti.','Şerifali Mh. Hendem Cd. Kule Sk. No:16-A Ümraniye / İSTANBUL','+90 216 499 99 10','sales.ia.turkey@deltaww.com','https://www.delta-turkey.com/');
INSERT INTO "katilimcilar" VALUES('DELTA VANA Kontrol Sistemleri ve Mühendislik San. Tic. A.Ş.','Tepeören Mh. Özvatan Cd. No:9 Araylar Sanayi Sitesi A Blok D:10/11 PK.34930 Tuzla/İSTANBUL','+90 216 517 82 82',' ','https://www.deltavana.com/');
INSERT INTO "katilimcilar" VALUES('DOSTEL Otomasyon Elektrik Elektronik San. Tic. Ltd. Şti.','Mescit Mh. Birmes San. Sit. A10 Blok No:12 Orhanlı 34956 Tuzla/İSTANBUL','+90 216 307 04 40/+90 216 307 04 41/+90 216 307 04 70','dostel@dostelotomasyon.net','https://www.dostelotomasyon.net/');
INSERT INTO "katilimcilar" VALUES('EGE Endüstriyel Kontrol Elektromekanik San. ve Tic. A.Ş.','Fabrika: İzmir Serbest Bölgesi (Izmir Free Zone) Menekşe Sk. No:8 PK.35674 Menemen / İZMİR','+90 232 842 61 60','info@egecontrols.com','https://www.egecontrols.com.tr/');
INSERT INTO "katilimcilar" VALUES('ELİAR Elektronik San. A.Ş.','Esentepe Mh. Sağlam Fikir Sk. No:1 PK. 34394 Şişli / İSTANBUL','+90 212 274 30 31',' ','https://www.eliar.com.tr/');
INSERT INTO "katilimcilar" VALUES('ELİMKO Elektronik Ltd. Şti.','ASO 2. Organize Sanayi Bölgesi, Alcı OSB Mah. 2001. Cad. No:14 PK.06909 Sincan / ANKARA','+90 312 212 64 50',' ','https://www.elimko.com.tr/');
INSERT INTO "katilimcilar" VALUES('EMERSON Process Management Ltd. Şti.','İçerenköy Mah. Topçu İbrahim Sk. No:13 Kat:3 - 4 34752 İçerenköy / İST.','+90 216 573 98 48','emine.hanife@emerson.com','https://www.emerson.com/');
INSERT INTO "katilimcilar" VALUES('EMİKON Elektronik San. ve Tic. Ltd. Şti.','Dudullu OSB Mh.DES Sanayi Sitesi 103. Sk. B-07 Blok No:34 PK.34776 Yukarı Dudullu / İSTANBUL','+90 216 420 83 45-46',' ','https://www.emikon.com.tr/');
INSERT INTO "katilimcilar" VALUES('EMKO Elektronik San. ve Tic. A.Ş.','Bursa Organize Sanayi Bölgesi (Fethiye OSB Mh.) Ali Osman Sönmez Bulv. 2. Sk. No:3 PK.16215 Nilüfer / BURSA','+90 224 261 19 00',' ','https://www.emkoelektronik.com.tr/');
INSERT INTO "katilimcilar" VALUES('ENTEK Otomasyon Ürünleri San. Tic. A.Ş.','Mahmutbey Mah. Taşocağı Yolu Cad. No:9 Entek Plaza Bağcılar 34218 / İST.','+90 850 201 41 41','info@entek.com.tr','https://www.entek.com.tr%20/');
INSERT INTO "katilimcilar" VALUES('ENTEK TEKNİK A.Ş.','Şerifali Mah. Alptekin Cad. No:73/2 Ümraniye 34775 / İST.','+90 216 459 86 60',' ','https://www.entekteknik.com/');
INSERT INTO "katilimcilar" VALUES('FESTO San. ve Tic. A.Ş.','İstanbul Anadolu Yakası OSB Aydınlı Mh. Üniversite Cd. No:45 TR-34953 Tuzla / İSTANBUL','+90 216 585 00 74',' ','https://www.festo.com.tr/');
INSERT INTO "katilimcilar" VALUES('GMT Endüstriyel Elektronik San. Ve Tic. A. Ş.','Çubuklu Mh. Boğaziçi Cd. Boğaziçi Plaza No:6/B Beykoz 34805 / İSTANBUL','+90 216 668 00 06 / +90 534 363 75 33 / +90 534 882 12 22','gmt@gmtcontrol.com','https://www.gmtcontrol.com/');
INSERT INTO "katilimcilar" VALUES('GSD - Genel Sistem Dizaynı Mühendislik Bilişim Taahhüt San. ve Tic. A.Ş.','D-100 Maltepe Kavşağı Zümrütevler Mh. Atatürk Cd. Nazmi İlker Sk. No:10 TR-34852 Maltepe / İSTANBUL','+90 216 458 48 48 (pbx) / +90 216 442 60 10',' ','https://www.gsdas.com/');
INSERT INTO "katilimcilar" VALUES('HALICI Endüstri Teknolojileri A.Ş.','Esenşehir Mh. Karaçam Sk. Halıcı Plaza No:3 PK.34776 Ümraniye / İSTANBUL','444 34 94 / +90 216 415 33 33','info@halici.com','https://www.halici.com/');
INSERT INTO "katilimcilar" VALUES('ifm electronic Otomasyon Ltd. Şti.','Esenşehir Mh. İlkyaz Sk. No:75/1 PK. 34776 Ümraniye / İSTANBUL','+90 216 645 00 00','info.tr@ifm.com','https://www.ifm.com.tr/');
INSERT INTO "katilimcilar" VALUES('İNTEGROL Entegre Kontrol Sistemleri Ltd. Şti.','Cevizli Mh. Bağdat Cd. No:519 Plaza 233 TR-34846 Maltepe / İSTANBUL','+90 216 442 11 32',' ','https://www.integrol.com/');
INSERT INTO "katilimcilar" VALUES('JUMO Ölçü Sistemleri ve Otomasyon San. ve Tic. Ltd. Şti.','Şerifali Mh. Bayraktar Bulvarı Burhan Sk. No:1 TR-34775 Ümraniye / İSTANBUL','+90 216 645 52 00','info.tr@jumo.net','https://www.jumo.com.tr/');
INSERT INTO "katilimcilar" VALUES('KPI Automation Endüstriyel Otomasyon Sistemleri Tic. San. Ltd. Şti.','Milangaz Cd. Monumento Kartal Plaza No:75/A D:17 Esentepe, 34870 Kartal / İSTANBUL','+90 216 372 82 82','project@kpi-automation.com','https://kpi-automation.com/');
INSERT INTO "katilimcilar" VALUES('LEUZE electronic San. ve Tic. Ltd. Şti.','Fatih Sultan Mehmet Mah. Aheste Sok. No: 7 Kat: 6 TR-34764 Ümraniye / İstanbul','+90 216 456 67 04','info.tr@leuze.com','https://www.leuze.com.tr/');
INSERT INTO "katilimcilar" VALUES('MCS Otomasyon San. Tic. Ltd. Şti.','Armağanevler Mh. Mithatpaşa Cd. No:148/10 Kat:3 TR-34770 Ümraniye / İSTANBUL','+90 216 505 0 701','info@mcs.com.tr','https://www.mcs.com.tr/');
INSERT INTO "katilimcilar" VALUES('METER Elektronik San. ve Tic. A.Ş.','3. Matbaacılar Sit. Yakuplu Mah. Başkent Cad. No:98 – 4 No. lu Giriş Beylikdüzü / İSTANBUL','+90 212 886 64 54 (8 hat)','info@meter.com.tr','https://www.meter.com.tr/');
INSERT INTO "katilimcilar" VALUES('NETES Mühendislik ve Dış Tic. A.Ş.','Küçük Çamlıca Mh. Oymak Çk. No:3 TR-34696 Üsküdar / İSTANBUL','+90 216 340 50 50','netes@netes.com.tr','https://www.netes.com.tr/');
INSERT INTO "katilimcilar" VALUES('NOVİ Robot Teknolojileri Otomasyon Yazılım San. Tic. Ltd. Şti.','Sepetlipınar Mah. Deniz Sk. No:18 PK.41275 Başiskele / KOCAELİ','+90 262 324 66 83','info@novirobotics.com','https://novirobotics.com/');
INSERT INTO "katilimcilar" VALUES('OPKON Optik Elektronik Kontrol San. ve Tic. A.Ş.','Terazidere Mh. 29 Ekim Cd. Güleçoğlu İş Mrk. No:34/1 PK.34035 Bayrampaşa / İSTANBUL','+90 212 501 48 63 pbx',' ','https://www.opkon.com.tr/');
INSERT INTO "katilimcilar" VALUES('PEPPERL+FUCHS Elektronik San. ve Tic. Ltd. Şti.','Atatürk Mh. Şeref Sk. No:9 TR-34758 Ataşehir / İSTANBUL','+90 216 577 22 50','info@tr.pepperl-fuchs.com','https://www.pepperl-fuchs.com/turkey/tr');
INSERT INTO "katilimcilar" VALUES('PROSES Mühendislik San. ve Tic. Ltd. Şti.','Başpınar OSB Mh. 2.Organize Sanayi Bölgesi Celal Doğan Bulv. No:10, 12.İş yeri PK. 27620 Şehitkamil / GAZİANTEP','+90 342 339 87 70 (4 Hat)','proses@proses.com.tr','https://www.proses.com.tr/');
INSERT INTO "katilimcilar" VALUES('PVD - Proses Vana Donanım San. ve Tic. Ltd. Şti.','Y.Dudullu Şerifali Mh. Serdivan Sk. No:50 TR-34775 Ümraniye / İSTANBUL','+90 216 415 65 40','info@pvd.com.tr','https://www.pvd.com.tr/');
INSERT INTO "katilimcilar" VALUES('ROCKWELL Otomasyon Tic. A.Ş.','Kar Plaza İş Merkezi İçerenköy Mh. Karaman Çiftlik Yolu Cd. No:47 E Blok Kat:6 PK.34752 Ataşehir / İSTANBUL','444 4 940 / +90 216 578 84 00','GToprak@ra.rockwell.com','https://www.rockwellautomation.com/tr-tr.html');
INSERT INTO "katilimcilar" VALUES('SICK - Sensörler ve İleri Cihazlar Kontrol A.Ş.','Şerifali Mah. Turgut Özal Bulvarı No:190-192 TR-34775 Ümraniye / İSTANBUL','+90 216 528 50 00','mehmet.kahveci@sick.com.tr','http://www.sick.com.tr/');
INSERT INTO "katilimcilar" VALUES('SİMTEKNO Endüstriyel Ürünler San. Tic. Ltd. Şti.','Oruç Reis Mah. Giyimkent Sit. 7. Sok. No: 85-87 Esenler 34235 / İSTANBUL','+90 212 537 62 74 / 0850 318 48 43','info@simtekno.com.tr','https://www.simtekno.com.tr/');
INSERT INTO "katilimcilar" VALUES('SMC Turkey Otomasyon A.Ş.','Teskoop Sanayi Bölgesi, Deliklikaya Mah. Fersah Cad. No:130-132/1 PK.34555 Arnavutköy / İSTANBUL','+90 212 489 0 440','info@smcturkey.com.tr','https://www.smcturkey.com.tr/');
INSERT INTO "katilimcilar" VALUES('SMS - Sanayi Malzemeleri Üretim ve Satışı A.Ş.','Bostancı Yolu Kuru Sk. No:16 Yukarı Dudullu 34776 Ümraniye / İSTANBUL','+90 216 364 34 05',' ','https://www.smstork.com/');
INSERT INTO "katilimcilar" VALUES('TURCK Otomasyon Tic. Ltd. Ști.','Cevizli Mah. Tansel Cad. No:76 Kat:12 PK.34846 Maltepe / İSTANBUL','+90 216 572 21 77','turkey@turck.com','https://www.turck.com.tr/');
INSERT INTO "katilimcilar" VALUES('WAGO Elektronik San. ve Tic. Ltd. Şti.','Tatlısu Mh. Arifay Sk. No:6 PK.34774 Ümraniye / İSTANBUL','+90 216 472 11 33','info.tr@wago.com','https://www.wago.com.tr/');
COMMIT;
